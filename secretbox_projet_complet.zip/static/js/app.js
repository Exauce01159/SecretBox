// Petites interactions communes à SecretBox.
document.querySelectorAll('form').forEach(form => {
  form.addEventListener('submit', () => {
    const button = form.querySelector('button[type="submit"]');
    if (button && !button.dataset.noLoading) {
      button.disabled = true;
      button.dataset.originalText = button.textContent;
      button.textContent = 'Envoi…';
      window.setTimeout(() => {
        button.disabled = false;
        button.textContent = button.dataset.originalText || 'Envoyer';
      }, 5000);
    }
  });
});
