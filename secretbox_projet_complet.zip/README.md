# SecretBox — plateforme de messages anonymes

## Fonctionnalités
- Création de compte et connexion.
- Lien public personnel `/u/nom`.
- Envoi anonyme de messages, questions, compliments, confessions et défis.
- Boîte de réception privée.
- Réponse aux messages et création d'une carte à partager en story.
- Jeux : vérité ou défi, note-moi sur 10, questions du jour.
- Masquage des messages et signalement.
- Protection CSRF des formulaires Flask-WTF et mots de passe hachés.

## Lancer en local
1. Installer Python 3.11 ou 3.12.
2. Ouvrir un terminal dans le dossier du projet.
3. Créer un environnement virtuel :
   - Windows : `py -m venv .venv`
   - Activation PowerShell : `.venv\Scripts\Activate.ps1`
   - Activation CMD : `.venv\Scripts\activate.bat`
4. Installer : `pip install -r requirements.txt`
5. Définir une clé secrète avant un usage réel :
   - PowerShell : `$env:SECRET_KEY="une-longue-cle-aleatoire"`
   - CMD : `set SECRET_KEY=une-longue-cle-aleatoire`
6. Démarrer : `python app.py`
7. Ouvrir `http://127.0.0.1:5000`.

## Déploiement sur Render
1. Créer un dépôt GitHub et y envoyer les fichiers.
2. Sur Render, choisir **New + → Blueprint** et sélectionner le dépôt.
3. Render lira `render.yaml`, créera le service web et la base PostgreSQL.
4. Attendre le déploiement, puis ouvrir l'URL fournie par Render.
5. Tester inscription, lien public, message, connexion, réponse et story.

## Important avant une utilisation publique
- Le plan d'hébergement et la disponibilité des bases de données peuvent changer : vérifier les conditions actuelles et les coûts.
- Ne pas utiliser `SECRET_KEY` de développement en production.
- La version de départ ne stocke pas l'identité ou l'adresse IP de l'expéditeur dans les messages, mais l'hébergeur peut conserver des journaux techniques. Ne promets donc pas un anonymat absolu.
- Ajouter avant une large diffusion : vérification email, politique de confidentialité, procédure de suppression de compte, protection anti-spam plus forte, modération des signalements et sauvegardes.
- Le jeu « note-moi » est une activité ludique ; empêcher les insultes et le harcèlement.
