import os
import re
from datetime import datetime, timezone
from urllib.parse import urlparse

from flask import Flask, render_template, redirect, url_for, flash, request, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user, login_required, current_user
)
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, SubmitField
from wtforms.validators import DataRequired, Length, EqualTo, ValidationError
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-only-change-this-secret-key")
database_url = os.environ.get("DATABASE_URL", "sqlite:///secretbox.db")
if database_url.startswith("postgres://"):
    database_url = database_url.replace("postgres://", "postgresql://", 1)
app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {"pool_pre_ping": True}
app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024  # 1 MB max request

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message = "Connecte-toi pour accéder à ton espace."
login_manager.login_message_category = "info"


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(24), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    messages = db.relationship("Message", backref="recipient", lazy=True, cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    body = db.Column(db.String(500), nullable=False)
    category = db.Column(db.String(20), nullable=False, default="secret")
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    reply = db.Column(db.String(500), nullable=True)
    is_hidden = db.Column(db.Boolean, default=False, nullable=False)


class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    message_id = db.Column(db.Integer, db.ForeignKey("message.id"), nullable=False)
    reason = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)


class RegisterForm(FlaskForm):
    username = StringField("Nom d’utilisateur", validators=[
        DataRequired(), Length(min=3, max=24)
    ])
    password = PasswordField("Mot de passe", validators=[
        DataRequired(), Length(min=8, message="Utilise au moins 8 caractères.")
    ])
    confirm = PasswordField("Confirmer le mot de passe", validators=[
        DataRequired(), EqualTo("password", message="Les mots de passe ne correspondent pas.")
    ])
    submit = SubmitField("Créer mon compte")

    def validate_username(self, field):
        if not re.fullmatch(r"[A-Za-z0-9_]+", field.data or ""):
            raise ValidationError("Utilise uniquement des lettres, chiffres et _.")
        if User.query.filter_by(username=(field.data or "").lower()).first():
            raise ValidationError("Ce nom d’utilisateur est déjà pris.")


class LoginForm(FlaskForm):
    username = StringField("Nom d’utilisateur", validators=[DataRequired()])
    password = PasswordField("Mot de passe", validators=[DataRequired()])
    submit = SubmitField("Se connecter")


class SendMessageForm(FlaskForm):
    body = TextAreaField("Ton message", validators=[DataRequired(), Length(min=1, max=500)])
    category = StringField("Type de message", validators=[DataRequired(), Length(max=20)])
    submit = SubmitField("Envoyer anonymement")


class ReplyForm(FlaskForm):
    reply = TextAreaField("Ta réponse", validators=[DataRequired(), Length(max=500)])
    submit = SubmitField("Enregistrer ma réponse")


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


class EmptyForm(FlaskForm):
    submit = SubmitField("")


@app.context_processor
def inject_site_name():
    return {"site_name": "SecretBox", "logout_form": EmptyForm()}


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/inscription", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    form = RegisterForm()
    if form.validate_on_submit():
        user = User(username=form.username.data.lower())
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash("Bienvenue sur SecretBox ! Ton lien personnel est prêt.", "success")
        return redirect(url_for("dashboard"))
    return render_template("register.html", form=form)


@app.route("/connexion", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=(form.username.data or "").lower()).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            return redirect(url_for("dashboard"))
        flash("Nom d’utilisateur ou mot de passe incorrect.", "danger")
    return render_template("login.html", form=form)


@app.route("/deconnexion", methods=["POST"])
@login_required
def logout():
    logout_user()
    flash("Tu es déconnecté.", "info")
    return redirect(url_for("index"))


@app.route("/u/<username>", methods=["GET", "POST"])
def public_profile(username):
    user = User.query.filter_by(username=username.lower()).first_or_404()
    form = SendMessageForm()
    allowed_categories = {"secret", "question", "compliment", "crush", "defi"}
    if form.validate_on_submit():
        category = (form.category.data or "secret").lower()
        if category not in allowed_categories:
            category = "secret"
        # Do not store sender identity or IP address in the message record.
        msg = Message(recipient_id=user.id, body=form.body.data.strip(), category=category)
        db.session.add(msg)
        db.session.commit()
        flash("Message envoyé ! 💌", "success")
        return redirect(url_for("public_profile", username=user.username))
    return render_template("public_profile.html", profile=user, form=form)


@app.route("/tableau-de-bord")
@login_required
def dashboard():
    messages = Message.query.filter_by(recipient_id=current_user.id, is_hidden=False)\
        .order_by(Message.created_at.desc()).all()
    return render_template("dashboard.html", messages=messages)


@app.route("/message/<int:message_id>/reponse", methods=["GET", "POST"])
@login_required
def reply_message(message_id):
    message = db.session.get(Message, message_id) or abort(404)
    if message.recipient_id != current_user.id:
        abort(403)
    form = ReplyForm()
    if form.validate_on_submit():
        message.reply = form.reply.data.strip()
        db.session.commit()
        flash("Réponse enregistrée. Tu peux maintenant la partager en story.", "success")
        return redirect(url_for("dashboard"))
    if request.method == "GET" and message.reply:
        form.reply.data = message.reply
    return render_template("reply.html", message=message, form=form)


@app.route("/message/<int:message_id>/supprimer", methods=["POST"])
@login_required
def delete_message(message_id):
    message = db.session.get(Message, message_id) or abort(404)
    if message.recipient_id != current_user.id:
        abort(403)
    message.is_hidden = True
    db.session.commit()
    flash("Message masqué de ta boîte.", "info")
    return redirect(url_for("dashboard"))


@app.route("/message/<int:message_id>/signaler", methods=["POST"])
def report_message(message_id):
    message = db.session.get(Message, message_id) or abort(404)
    reason = (request.form.get("reason") or "Contenu inapproprié").strip()[:200]
    db.session.add(Report(message_id=message.id, reason=reason))
    db.session.commit()
    flash("Signalement reçu. Merci de contribuer à un espace plus sûr.", "success")
    return redirect(url_for("public_profile", username=message.recipient.username))


@app.route("/jeux")
def games():
    return render_template("games.html")


@app.route("/story/<int:message_id>")
@login_required
def story(message_id):
    message = db.session.get(Message, message_id) or abort(404)
    if message.recipient_id != current_user.id:
        abort(403)
    if not message.reply:
        flash("Ajoute d’abord une réponse avant de créer ta carte story.", "info")
        return redirect(url_for("reply_message", message_id=message.id))
    return render_template("story.html", message=message)


@app.errorhandler(413)
def too_large(_error):
    return "La requête est trop volumineuse.", 413


@app.cli.command("init-db")
def init_db():
    """Créer les tables : flask --app app init-db"""
    db.create_all()
    print("Base de données initialisée.")


with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1")
